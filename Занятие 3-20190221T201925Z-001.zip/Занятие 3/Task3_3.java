package Lesson3home_work;

import java.util.Scanner;

public class Task3_3 {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("������� ����� �����: ");
		int a = scanner.nextInt();
		{
			System.out.println(toSquare(a));
		}
	}

	public static int toSquare(int a) {
		int b = (int) Math.pow(a, 2);
		return b;
	}
}
