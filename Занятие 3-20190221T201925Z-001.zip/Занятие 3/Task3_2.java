package Lesson3home_work;

import java.util.Scanner;

public class Task3_2 {
	public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("������� ����� �����: ");
		int a = scanner.nextInt(); 
		
		{
			System.out.println(even(a));
		}
	}
	public static boolean even(int a) {
		if (a%2==0 ) {
			return (true);
		}
		
		return false;
	}
}
