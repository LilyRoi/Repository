package Lesson4home_work;

public class Massive {
	int sum = 0;
	int a;

	public void printMassiveAsLine(int[] array) {
		// this.array = array;
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}

	public void printReverseMassiveAsLine(int[] array) {
		for (int i = array.length - 1; i >= 0; i--)
			System.out.print(array[i] + " ");
	}

	public int getSumOfElements(int[] array) {
		for (int i = 0; i < array.length; i++) {
			sum = sum + array[i];
		}
		return sum;
	}

	public int[] multiptyBy3(int[] array) {
		int[] array2 = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			array2[i] = array[i] * 3;
		}
		return array2;
	}
}
