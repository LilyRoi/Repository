package Lesson4home_work;

public class MainForMassive {
	public static void main(String[] args) {
		int[] array = { 1, 2, 3, 4, 5, 6, 7 };
		Massive massive = new Massive();
		massive.printMassiveAsLine(array);
		massive.printReverseMassiveAsLine(array);
		int sum = massive.getSumOfElements(array);
		System.out.println("����� ��������� ����� " + sum);
		int[] array2 = massive.multiptyBy3(array);
		massive.printMassiveAsLine(array2);
		massive.printReverseMassiveAsLine(array2);

	}

}
