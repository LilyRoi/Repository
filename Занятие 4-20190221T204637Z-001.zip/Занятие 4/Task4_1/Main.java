package Lesson4home_work;

public class Main {
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("Maria");
		person.setSurname("Sambuk");
		person.setAge(20);
		person.setPhone("80336521371");
		person.printAllInformation();
		person.printName();
		person.isAdult();
	}
}
