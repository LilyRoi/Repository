package core;

public class BasicTypes {
	public static void main(String[] args) { 
		 byte a; 
		 int b;
		 int c = 10, c1 = 0777, c2 = 0x32, c3 = 0b10;
		 short ds = 12;
		 long dL = 12222;
		 double d = 999999.25;
		 float dF = 99.25f;
		 char e = 'x';
		 boolean f = true;
		 a = 1; b = 2;
		 System.out.println(a + " " + b + " " + c + " " + d + " " + e + " " + f); }}
