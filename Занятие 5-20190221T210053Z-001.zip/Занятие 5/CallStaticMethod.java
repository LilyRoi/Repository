package Lesson5home_work;

public class CallStaticMethod {
	public static void main(String[] args) {
		Tester.printHello();
	}
}
