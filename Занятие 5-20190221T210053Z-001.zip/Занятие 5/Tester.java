package Lesson5home_work;

public class Tester {

	public String name;
	public String surname;
	public int expirienceInYears;
	public String englishLevel;
	public double salary;

	public Tester(String name, String surname, int expirienceInYears) {
		this.name = name;
		this.surname = surname;
		this.expirienceInYears = expirienceInYears;
	}

	public Tester(String name, String surname, int expirienceInYears,
			String englishLevel) {
		this(name, surname, expirienceInYears);
		this.englishLevel = englishLevel;
	}

	public Tester(String name, String surname, int expirienceInYears,
			String englishLevel, double salary) {
		this(name, surname, expirienceInYears, englishLevel);
		this.salary = salary;
	}

	public void print(String name, String surname, int expirienceInYears) {
		System.out.println("I am " + name + " " + surname + " " + "with" + " "
				+ expirienceInYears + "years of experience");
	}

	public void print(String name, String surname, int expirienceInYears,
			String englishLevel) {
		System.out.println("I am " + name + " " + surname + " " + "with" + " "
				+ expirienceInYears + "years of experience " + "and with "
				+ englishLevel + "" + "level of English");
	}

	public void print(String name, String surname, int expirienceInYears,
			String englishLevel, double salary) {
		System.out.println("I am " + name + " " + surname + " " + "with" + " "
				+ expirienceInYears + "years of experience " + "and with "
				+ englishLevel + "" + "level of English and the salary "
				+ salary);
	}

	public static void printHello() {
		System.out.println("Hello!");
	}
}
