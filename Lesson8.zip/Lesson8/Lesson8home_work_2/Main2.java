
package Lesson8home_work_2;

import Lesson8home_work.Tester;

public class Main2 {
	public static void main(String[] args) {
		Tester tester = new Tester("Maria", "Sambuk", 5, 10000, "Advanced");		
		
		//tester.getDoubleSalary(); //not possible, because it is private 
		//tester.getExpirienceInMonths(); //not possible, because it has default modificator and not visible from other packages
		//tester.printNameAndSurname(); //not possible, because it is protected
		tester.printAll();
		//tester.setName("Masha"); //not possible, because it has default modificator and not visible from other package
		//tester.getName();//not possible, because it has default modificator and not visible from other package
		//tester.getSurname();//not possible, because it has default modificator and not visible from other package
		//tester.setSurname("Sambuk2");	//not possible, because it has default modificator and not visible from other package
		//tester.getExpirienceInYears();//not possible, because it has default modificator and not visible from other package
		//tester.setExpirienceInYears(6);//not possible, because it has default modificator and not visible from other package
		//tester.getSalary();//not possible, because it has default modificator and not visible from other package
		//tester.setSalary(8000);//not possible, because it has default modificator and not visible from other package
		//tester.getEnglishLevel();//not possible, because it has default modificator and not visible from other package
		//tester.setEnglishLevel("Proficiency");//not possible, because it has default modificator and not visible from other package

	}

}
