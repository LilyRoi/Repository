package Lesson8home_work;

public class Main {

	public static void main(String[] args) {
		Tester tester = new Tester("Maria", "Sambuk", 7, 1000000, "Advanced");

		// tester.getDoubleSalary(); //not possible, because it is private
		tester.getExpirienceInMonths();
		tester.printNameAndSurname();
		tester.printAll();
		tester.setName("Masha");
		tester.getName();
		tester.getSurname();
		tester.setSurname("Sambuk2");
		tester.getExpirienceInYears();
		tester.setExpirienceInYears(6);
		tester.getSalary();
		tester.setSalary(8000);
		tester.getEnglishLevel();
		tester.setEnglishLevel("Proficiency");

	}

}
