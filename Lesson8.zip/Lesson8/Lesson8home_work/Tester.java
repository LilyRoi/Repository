package Lesson8home_work;

public class Tester {
	private String name;
	String surname;
	protected int expirienceInYears;
	public double salary;
	String englishLevel;

	Tester(String name, String surname) {
		this.name = name;
		this.surname = surname;
	}

	Tester(String name, String surname, int expirienceInYears) {
		this(name, surname);
		this.expirienceInYears = expirienceInYears;
	}

	public Tester(String name, String surname, int expirienceInYears,
			double salary, String englishLevel) {
		this(name, surname, expirienceInYears);
		this.salary = salary;
		this.englishLevel = englishLevel;

	}

	void setName(String name) {
		this.name = name;
	}

	String getName() {
		return this.name;
	}

	void setSurname(String surname) {
		this.surname = surname;
	}

	String getSurname() {
		return surname;
	}

	void setExpirienceInYears(int expirienceInYears) {
		this.expirienceInYears = expirienceInYears;
	}

	int getExpirienceInYears() {
		return expirienceInYears;
	}

	void setSalary(double salary) {
		this.salary = salary;
	}

	double getSalary() {
		return salary;
	}

	void setEnglishLevel(String englishLevel) {
		this.englishLevel = englishLevel;
	}

	String getEnglishLevel() {
		return englishLevel;
	}

	private double getDoubleSalary() {
		return salary * 2;
	}

	int getExpirienceInMonths() {
		return expirienceInYears * 12;
	}

	protected void printNameAndSurname() {
		System.out.println(name + " " + surname);
	}

	public void printAll() {
		System.out.println("Name: " + name + "; Surname: " + surname
				+ "; ExpirienceInYears: " + expirienceInYears + "; Salary: "
				+ salary + "; EnglishLevel: " + englishLevel);
	}

}
